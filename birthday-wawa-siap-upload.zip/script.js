document.addEventListener("DOMContentLoaded", function() {

    // 1. OPENING SCREEN
    const startButton = document.getElementById("startButton");
    const opening = document.getElementById("opening");
    const mainContent = document.getElementById("mainContent");
    const music = document.getElementById("birthdayMusic");

    if (startButton && opening && mainContent) {
        startButton.addEventListener("click", async function() {

            opening.style.display = "none";
            mainContent.style.display = "block";
            // CONFETTI EFFECT
            for (let i = 0; i < 50; i++) {
                const confetti = document.createElement("span");

                confetti.classList.add("confetti");

                confetti.style.left = Math.random() * 100 + "vw";
                confetti.style.animationDelay = Math.random() * 1.5 + "s";

                const colors = ["#8db9dc", "#d5eaff", "#ffffff", "#b6d9f5"];
                confetti.style.backgroundColor =
                    colors[Math.floor(Math.random() * colors.length)];

                document.body.appendChild(confetti);

                setTimeout(function() {
                    confetti.remove();
                }, 4500);
            }

            if (music) {
                try {
                    await music.play();
                } catch (error) {
                    console.log("Musik gagal diputar:", error);
                }
            }

        });
    }
    // BIRTHDAY COUNTDOWN
const birthdayDate = new Date("2026-11-25T00:00:00+07:00").getTime();

function updateCountdown() {
    const now = new Date().getTime();
    const distance = birthdayDate - now;

    if (distance <= 0) {
        document.getElementById("countdown").innerHTML =
            "<h2>Happy Birthday, Wawa! ♡</h2>";
        return;
    }

    document.getElementById("days").textContent =
        Math.floor(distance / (1000 * 60 * 60 * 24));

    document.getElementById("hours").textContent =
        Math.floor((distance / (1000 * 60 * 60)) % 24);

    document.getElementById("minutes").textContent =
        Math.floor((distance / (1000 * 60)) % 60);

    document.getElementById("seconds").textContent =
        Math.floor((distance / 1000) % 60);
}

updateCountdown();
setInterval(updateCountdown, 1000);

// TYPING EFFECT
const title = "Happy Birthday, Wawa! ♡";
const message = "Wishing you all the happiness in the world. May your day be filled with love and beautiful memories.";

const titleElement = document.getElementById("typingTitle");
const textElement = document.getElementById("typingText");

let titleIndex = 0;
let textIndex = 0;

function typeTitle() {
    if (titleIndex < title.length) {
        titleElement.textContent += title.charAt(titleIndex);
        titleIndex++;
        setTimeout(typeTitle, 100);
    } else {
        typeMessage();
    }
}

function typeMessage() {
    if (textIndex < message.length) {
        textElement.textContent += message.charAt(textIndex);
        textIndex++;
        setTimeout(typeMessage, 40);
    }
}

if (titleElement && textElement) {
    typeTitle();
}

    // 2. OPEN ENVELOPE
    const openLetter = document.getElementById("openLetter");
    const envelope = document.getElementById("envelope");
    const letter = document.getElementById("letter");

    if (openLetter && envelope && letter) {
        openLetter.addEventListener("click", function() {

            envelope.classList.add("hide");

            setTimeout(function() {
                envelope.style.display = "none";
                letter.classList.add("show");
            }, 500);

        });
    }

    // 3. SECRET MESSAGE
    const secretButton = document.getElementById("secretButton");
    const secretText = document.getElementById("secretText");

    if (secretButton && secretText) {
        secretButton.addEventListener("click", function() {

            secretText.classList.toggle("show");

            secretButton.innerHTML =
                secretText.classList.contains("show")
                ? "Hide Message ♡"
                : "One Last Thing ♡";

        });
    }
    // BACK TO TOP
const backToTop = document.getElementById("backToTop");

window.addEventListener("scroll", function() {
    backToTop.style.display =
        window.scrollY > 200 ? "block" : "none";
});

backToTop.addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});

});
